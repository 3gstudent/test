#pragma once
#include "kuhl_m.h"

const KUHL_M kuhl_m_standard;

NTSTATUS kuhl_m_standard_exit(int argc, wchar_t * argv[]);
NTSTATUS kuhl_m_standard_log(int argc, wchar_t * argv[]);
